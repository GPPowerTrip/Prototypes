from rdflib import Graph, RDF, URIRef,  RDFS #, Literal, BNode
from SPARQLWrapper import SPARQLWrapper, JSON
import sys, getopt


class ServiceSystem:
    'A API to a Service Systems'
    filename = ''
    g = Graph()

    def __init__(self, filename):
        ServiceSystem.filename = filename
        ServiceSystem.g.parse(filename, format='n3')

    #------------------------------------------------------------------
    #---------- Show information about the Service System -------------
    #------------------------------------------------------------------
    def getServiceInformation(self):

       URIServiceSystem = URIRef("http://w3id.org/lss-usdl/v2#ServiceSystem")
       if ( None, RDF.type, URIServiceSystem ) in ServiceSystem.g:
           lss = ServiceSystem.g.value(predicate = RDF.type, object = URIServiceSystem, any = False)
           #print "Service System found! " + lss
       else:
           raise Exception("Cannot find Service System!!")

       if ( None, RDF.type, URIServiceSystem ) in ServiceSystem.g:
           lss_description = ServiceSystem.g.value(predicate = RDFS.comment, subject = lss, any = False)
           #print "Service System description found! " + lss_description
       else:
           raise Exception("Cannot find Service System description!!")

# Can also be done this way
#       for lss in ServiceSystem.g.subjects(RDF.type, URIRef("http://w3id.org/lss-usdl/v2#ServiceSystem")):
#           print "Service System Name: ", lss.rsplit("#", 2)[1]
#       for lss_description in ServiceSystem.g.objects(lss, RDFS.comment):
#           print "Description:", lss_description

       information=[]
       information.append(lss)
       information.append(lss_description)

       return information


    #------------------------------------------------------------------
    #-------------- Get Interactions   --------------------------------
    #------------------------------------------------------------------
    def getInteractions(self):
        qres = ServiceSystem.g.query(
            """PREFIX  lss-usdl:  <http://w3id.org/lss-usdl/v2#>
                SELECT DISTINCT ?a ?b
                WHERE {
                  ?a lss-usdl:hasInteraction ?b .
                }""")

        results = []
        for row in qres:
            s, r = row
            sl = s.rsplit("#", 2)[1]
            rl = r.rsplit("#", 2)[1]
            results.append(rl)
            #print sl, "hasInteraction", rl

        return results

# Can also be done this way
#       print("")
#       print "--- Interaction Points: ---"
#       for sub, obj in ServiceSystem.g.subject_objects(URIRef("http://w3id.org/lss-usdl/v2#hasInteraction")):
#          interaction = obj.rsplit("#", 2)[1]
#          print interaction


    #------------------------------------------------------------------
    #-------------- Connectors ----------------------------------------
    #------------------------------------------------------------------
    def getConnectors(self):
        qres = ServiceSystem.g.query(
            """PREFIX  lss-usdl:  <http://w3id.org/lss-usdl/v2#>
                SELECT DISTINCT ?src ?tgt ?cond
                WHERE {
                  ?ss lss-usdl:hasControlFlow ?cf.
                  ?cf lss-usdl:hasSource ?src  .
                  ?cf lss-usdl:hasTarget ?tgt .
                  ?cf lss-usdl:hasCondition ?cond .
                }""")

        results = []
        for row in qres:
            src, tgt, cond = row
            source = src.rsplit("#", 2)[1]
            target = tgt.rsplit("#", 2)[1]
            condition = cond
            results.append([source, target, condition])
            #str = 'ControlFlow (' + source + ' -> ' + target + ') with condition "' + condition + '"'''
            #print str

        return results


    #------------------------------------------------------------------
    #-------------- Get Service Roles ---------------------------------
    #------------------------------------------------------------------
    def getRoles(self):
        qres = ServiceSystem.g.query(
            """PREFIX  lss-usdl:  <http://w3id.org/lss-usdl/v2#>
                SELECT DISTINCT ?role
                WHERE {
                  ?s ?prop ?o .
                  ?lss lss-usdl:hasInteraction ?int .
                  ?int lss-usdl:performedBy ?role .
                }""")

        results = []
        for row in qres:
            r=getattr(row, "role")
            role = r.rsplit("#", 2)[1]
            results.append(role)

        return results

    # GET GOALS
    def getGoals(self):
        qres = ServiceSystem.g.query(
            """PREFIX  lss-usdl:  <http://w3id.org/lss-usdl/v2#>
                SELECT DISTINCT ?goal
                WHERE {
                  ?s ?prop ?o .
                  ?lss lss-usdl:hasInteraction ?int .
                  ?int lss-usdl:hasGoal ?goal .
                }""")

        results = []
        for row in qres:
            r=getattr(row, "goal")
            goal = r.rsplit("#", 2)[1]
            results.append(goal)

        return results

    # GET LOCATIONS
    def getLocations(self):
    	qres = ServiceSystem.g.query(
            """PREFIX  lss-usdl:  <http://w3id.org/lss-usdl/v2#>
                SELECT DISTINCT ?location
                WHERE {
                  ?s ?prop ?o .
                  ?lss lss-usdl:hasInteraction ?int .
                  ?int lss-usdl:hasLocation ?location .
                }""")

        results = []
        for row in qres:
            r=getattr(row, "location")
            location = r.rsplit("#", 2)[1]
            results.append(location)

        return results

    #GET TIME
    def getTime(self):
        qres = ServiceSystem.g.query(
            """PREFIX  lss-usdl:  <http://w3id.org/lss-usdl/v2#>
                SELECT DISTINCT ?temporaltime
                WHERE {
                  ?s ?prop ?o .
                  ?lss lss-usdl:hasInteraction ?int .
                  ?int lss-usdl:hasTime ?time .
                  ?time lss-usdl:hasTemporalEntity ?temporaltime
                }""")

        results = []
        for row in qres:
            r=getattr(row, "temporaltime")
            temporaltime = r.rsplit("#", 2)[1]
            results.append(temporaltime)

        return results



#------------------------------------------------------------------
#-------------- Interactions done by Role -------------------------
#------------------------------------------------------------------
    def getInterationsByRole(self):
        qres = ServiceSystem.g.query(
            """PREFIX  lss-usdl:  <http://w3id.org/lss-usdl/v2#>
                SELECT DISTINCT ?lss ?int ?role
                WHERE {
                  ?lss lss-usdl:hasInteraction ?int .
                  ?int lss-usdl:performedBy ?role .
                }""")

        results = []
        for row in qres:
            s, i, r = row
            service = s.rsplit("#", 2)[1]
            interaction = i.rsplit("#", 2)[1]
            role = r.rsplit("#", 2)[1]
            results.append([interaction, role])

        return results


#------------------------------------------------------------------
#-------------- Interactions that receive and returns Resources ---
#------------------------------------------------------------------
    def getInteractionResources(self):
        qres = ServiceSystem.g.query(
        """PREFIX  lss-usdl:  <http://w3id.org/lss-usdl/v2#>
            SELECT DISTINCT ?lss ?int ?resource
            WHERE {
              ?lss lss-usdl:hasInteraction ?int .
              ?int lss-usdl:receivesResource ?resource .
              ?int lss-usdl:returnsResource ?resource .
            }""")

        results = []
        for row in qres:
            s, i, r = row
            service = s.rsplit("#", 2)[1]
            interaction = i.rsplit("#", 2)[1]
            resource = r.rsplit("#", 2)[1]
            results.append([interaction, resource])

        return results

#------------------------------------------------------------------
#-------------- Interactions that only receive Resources: ---------
#------------------------------------------------------------------
    def getInteractionResourcesReceived(self):
        qres = ServiceSystem.g.query(
            """PREFIX  lss-usdl:  <http://w3id.org/lss-usdl/v2#>
                SELECT DISTINCT ?lss ?int ?role
                WHERE {
                  ?lss lss-usdl:hasInteraction ?int .
                  ?int lss-usdl:receivesResource ?role .
                }""")

        results = []
        for row in qres:
            s, i, r = row
            service = s.rsplit("#", 2)[1]
            interaction = i.rsplit("#", 2)[1]
            resource = r.rsplit("#", 2)[1]
            results.append([interaction, resource])

        return results


#------------------------------------------------------------------
#-------------- Print first interaction: --------------------------
#------------------------------------------------------------------
# Look for an interaction which is a source but not the target of any connector
#
    def getFirstInteraction(self):
        qres = ServiceSystem.g.query(
            """PREFIX  lss-usdl: <http://w3id.org/lss-usdl/v2#>
               PREFIX time: <http://www.w3.org/2006/time/>
                SELECT DISTINCT ?lss ?tgt
                WHERE {
                  ?lss lss-usdl:hasControlFlow ?cf.
                  ?cf lss-usdl:hasSource ?src  .
                  ?cf lss-usdl:hasTarget ?tgt .
                  MINUS {?temp lss-usdl:hasTarget ?src .}
                }""")

        interaction = ''
        for row in qres:
            s, i= row
            service = s.rsplit("#", 2)[1]
            interaction = i.rsplit("#", 2)[1]

        return interaction



#------------------------------------------------------------------
#-------------- get last interaction(s) -------------------------
#------------------------------------------------------------------
# Look for an interaction which is a target but not the source of any connector
#
    def getLastInteraction(self):
        qres = ServiceSystem.g.query(
            """PREFIX  lss-usdl: <http://w3id.org/lss-usdl/v2#>
               PREFIX time: <http://www.w3.org/2006/time/>
                SELECT DISTINCT ?lss ?tgt
                WHERE {
                  ?lss lss-usdl:hasControlFlow ?cf.
                  ?cf lss-usdl:hasSource ?src  .
                  ?cf lss-usdl:hasTarget ?tgt .
                  MINUS {?temp lss-usdl:hasSource ?tgt .}
                }""")

        interaction = ''
        for row in qres:
            s, i= row
            service = s.rsplit("#", 2)[1]
            interaction = i.rsplit("#", 2)[1]

        return interaction



#------------------------------------------------------------------
#-------------- get DBpedia Resources -----------------------------
#------------------------------------------------------------------
    def getDBPediaResources(self):
        qres = ServiceSystem.g.query(
            """PREFIX  lss-usdl: <http://w3id.org/lss-usdl/v2#>
               PREFIX dbpedia: <http://dbpedia.org/>
                SELECT DISTINCT ?int ?res ?dbres
                WHERE {
                  ?lss lss-usdl:hasInteraction ?int .
                  ?int lss-usdl:createsResource ?res .
                  ?res a ?dbres .
                }""")

        results = []
        for row in qres:
            i, r, dbr = row
            interaction = i.rsplit("#", 2)[1]
            resource = r.rsplit("#", 2)[1]
            results.append([interaction, resource, dbr])

        return results

#------------------------------------------------------------------
#-------------- get Abstract for DBpedia Resource -----------------
#------------------------------------------------------------------


 
    def getSeeAlsoProperties(self):
        qres = ServiceSystem.g.query(
            """PREFIX  rdfs: <http://www.w3.org/2000/01/rdf-schema#> 
                SELECT DISTINCT ?getSeeAlso
                WHERE {
                  ?s ?prop ?o .
                  ?lss rdfs:seeAlso ?getSeeAlso .
                }""")

        results = []
        for row in qres:
            r=getattr(row, "getSeeAlso")
            getSeeAlso = r.rsplit("#", 2)[1]
            results.append(getSeeAlso)

        return results       

    def getSameAsProperties(self):
        qres = ServiceSystem.g.query(
            """PREFIX  owl: <http://www.w3.org/2002/07/owl#> 
                SELECT DISTINCT ?getSameAs
                WHERE {
                  ?s ?prop ?o .
                  ?lss owl:sameAs ?getSameAs .
                }""")

        results = []
        for row in qres:
            r=getattr(row, "getSameAs")
            getSameAs = r.rsplit("#", 2)[1]
            results.append(getSameAs)

        return results  

    def getSubClassOfProperties(self):
        qres = ServiceSystem.g.query(
            """PREFIX  rdfs: <http://www.w3.org/2000/01/rdf-schema#> 
                SELECT DISTINCT ?getSubClassOf
                WHERE {
                  ?s ?prop ?o .
                  ?lss rdfs:subclassOf ?getSubClassOf .
                }""")

        results = []
        for row in qres:
            r=getattr(row, "getSubClassOf")
            getSubClassOf = r.rsplit("#", 2)[1]
            results.append(getSubClassOf)

        return results  


    def getResourcesCreated(self):
        qres = ServiceSystem.g.query(
      	    """PREFIX  lss-usdl:  <http://w3id.org/lss-usdl/v2#>

                SELECT DISTINCT ?cr

                WHERE {

                  ?s ?prop ?o .

                  ?a lss-usdl:hasInteraction ?int .

                  ?int lss-usdl:createsResource ?cr .

                }""")

        results = []
        for row in qres:
            r=getattr(row, "cr")
            cr = r.rsplit("#", 2)[1]
            results.append(cr)

        return results  

    def getResourcesReceived(self):
        qres = ServiceSystem.g.query(
      	    """PREFIX  lss-usdl:  <http://w3id.org/lss-usdl/v2#>

                SELECT DISTINCT ?rrec

                WHERE {

                  ?s ?prop ?o .

                  ?a lss-usdl:hasInteraction ?int .

                  ?int lss-usdl:receivesResource ?rrec .

                }""")

        results = []
        for row in qres:
            r=getattr(row, "rrec")
            rrec = r.rsplit("#", 2)[1]
            results.append(rrec)

        return results  

    def getResourcesConsumed(self):
        qres = ServiceSystem.g.query(
      	    """PREFIX  lss-usdl:  <http://w3id.org/lss-usdl/v2#>

                SELECT DISTINCT ?rc

                WHERE {

                  ?s ?prop ?o .

                  ?a lss-usdl:hasInteraction ?int .

                  ?int lss-usdl:consumesResource ?rc .

                }""")

        results = []
        for row in qres:
            r=getattr(row, "rc")
            rc = r.rsplit("#", 2)[1]
            results.append(rc)

        return results  

    def getResourcesReturned(self):
        qres = ServiceSystem.g.query(
      	    """PREFIX  lss-usdl:  <http://w3id.org/lss-usdl/v2#>

                SELECT DISTINCT ?ret

                WHERE {

                  ?s ?prop ?o .

                  ?a lss-usdl:hasInteraction ?int .

                  ?int lss-usdl:returnsResource ?ret .

                }""")

        results = []
        for row in qres:
            r=getattr(row, "ret")
            ret = r.rsplit("#", 2)[1]
            results.append(ret)

        return results  

    def getXorOrAnd(self):
    	qres = ServiceSystem.g.query(
			"""PREFIX  lss-usdl:  <http://w3id.org/lss-usdl/v2#>

                SELECT DISTINCT ?a

                WHERE {
                {

                  ?a a lss-usdl:AND .
                  } UNION {
                  ?a a lss-usdl:OR .
                  } UNION {
                  ?a a lss-usdl:XOR .
                  }

                }""")      

        results = []
        for row in qres:  		    
            r=getattr(row, "a")
            a = r.rsplit("#", 2)[1]
            results.append(a)
        return results

    def getXor(self):
      qres = ServiceSystem.g.query(
      """PREFIX  lss-usdl:  <http://w3id.org/lss-usdl/v2#>

                SELECT DISTINCT ?a

                WHERE {

                  ?a a lss-usdl:XOR .

                }""")

              

      results = []
      for row in qres:
        r=getattr(row, "a")
        ret = r.rsplit("#", 2)[1]
        results.append(ret)
      return results


    def getOr(self):
      qres = ServiceSystem.g.query(
      """PREFIX  lss-usdl:  <http://w3id.org/lss-usdl/v2#>

                SELECT DISTINCT ?a

                WHERE {

                  ?a a lss-usdl:OR .

                }""")

              

      results = []
      for row in qres:
        r=getattr(row, "a")
        ret = r.rsplit("#", 2)[1]
        results.append(a)
      return results

    def getAnd(self):
      qres = ServiceSystem.g.query(
      """PREFIX  lss-usdl:  <http://w3id.org/lss-usdl/v2#>

                SELECT DISTINCT ?a

                WHERE {

                  ?a a lss-usdl:AND .

                }""")      

      results = []
      for row in qres:
        r=getattr(row, "a")
        ret = r.rsplit("#", 2)[1]
        results.append(a)
      return results

    def getSixStarComments(self):
      qres = ServiceSystem.g.query(
      """PREFIX  lss-usdl:  <http://w3id.org/lss-usdl/v2#>

                SELECT ?time ?goal ?role ?location

                WHERE {
                  {
                  ?a a ?b .
                  ?a rdfs:comment ?time .
                  FILTER(regex(str(?a),"time","i"))
                } UNION{
                  ?a a lss-usdl:Goal .
                  ?a rdfs:comment ?goal .
                } UNION{
                  ?a a lss-usdl:Role .
                  ?a rdfs:comment ?role .
                } UNION{
                  ?a a lss-usdl:Location .
                  ?a rdfs:comment ?location .
                }

                }""") 

      results = []
      for row in qres:
        print row

      return results

    def getExistingKnowledge(self):
      qres = ServiceSystem.g.query(
        """PREFIX  lss-usdl:  <http://w3id.org/lss-usdl/v2#>

        SELECT  ?dbpedia ?freebase ?geonames ?hrm
          WHERE {
            {
          ?temp1 ?temp2 ?dbpedia .
          FILTER(regex(str(?dbpedia),"dbpedia","i")) .
          } UNION {
          ?temp1 ?temp2 ?freebase .
          FILTER(regex(str(?freebase),"freebase","i")) .
          } UNION{
          ?temp1 ?temp2 ?hrm .
          FILTER(regex(str(?hrm),"HRM","i")) .
          } UNION{
          ?temp1 ?temp2 ?geonames .
          FILTER(regex(str(?geonames),"GeoNames","i")) .
        }
      }""")

      results = []
      for row in qres:
        print row

      return results           

#------------------------------------------------------------------
#-------------- parse command line  -------------------------------
#------------------------------------------------------------------

if __name__ == "__main__":

    inputfile = ''
    try:
        opts, args = getopt.getopt(sys.argv[1:],"hf:",["file="])
    except getopt.GetoptError:
        print 'LSS-USDL_API.py -f <service_system_file>'
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print 'LSS-USDL_API.py -f <service_system_file>'
            sys.exit()
        elif opt in ("-f", "--file"):
            inputfile = arg

    print 'Input file is: ', inputfile
    print("")

    ss = ServiceSystem("file:" + inputfile)
    results = ss.getServiceInformation()
    print "Service System name: " + results[0].rsplit("#", 2)[1]
    print "Service System desc: " + results[1]
    print("")

    results = ss.getInteractions()
    for interation in results:
        print "Interaction: " + interation
    print("")

    results = ss.getConnectors()
    for result in results:
        str = 'getConnectors: (' + result[0] + ' -> ' + result[1] + ') with condition "' + result[2] + '"'''
        print str
    print("")

    results = ss.getRoles()
    for role in results:
        print "getRoles: " + role
    print("")

    results = ss.getGoals()
    for goal in results:
        print "getGoals: " + goal
    print("")

    results = ss.getLocations()
    for location in results:
        print "getLocations: " + location
    print("")

    results = ss.getTime()
    for temporaltime in results:
        print "getTime: " + temporaltime
    print("")
    
    results = ss.getInterationsByRole()
    for result in results:
        str = 'getInterationsByRole: ' + result[0] + ' with role ' + result[1]
        print str
    print("")

    results = ss.getInteractionResources()
    for result in results:
        str = 'getInteractionResources: ' + result[0] + ' with resource ' + result[1]
        print str
    print("")

    results = ss.getInteractionResourcesReceived()
    for result in results:
        str = 'getInteractionResourcesReceived: ' + result[0] + ' with resource ' + result[1]
        print str
    print("")

    results = ss.getFirstInteraction()
    if results:
        str = 'getFirstInteraction: ' + results
        print str
        print("")

    results = ss.getLastInteraction()
    if results:
        str = 'getLastInteraction: ' + results
        print str
        print("")

    results = ss.getDBPediaResources()
    for result in results:
        str = 'getDBPediaResources: ' + result[0] + ' with resource ' + result[1] + ' -> ' + result[2]
        print str
    print("")



    results = ss.getSeeAlsoProperties()
    for seeAlso in results:
        print "getSeeAlso: " + seeAlso
    print("")

    results = ss.getSameAsProperties()
    for sameAs in results:
        print "getSameAs: " + sameAs
    print("")


    results = ss.getSubClassOfProperties()
    for subclassOf in results:
        print "getSubClassOf: " + subclassOf
    print("")

    results = ss.getResourcesCreated()
    for cr in results:
        print "getCreateResources: " + cr
    print("")

    results = ss.getResourcesReceived()
    for crec in results:
        print "getResourcesReceived: " + crec
    print("")

    results = ss.getResourcesConsumed()
    for rc in results:
        print "getResourcesConsumed: " + cr
    print("")

    results = ss.getResourcesReturned()
    for cret in results:
        print "getResourcesReturned: " + cret
    print("")


    results = ss.getXorOrAnd()
    for a in results:
    	print "getXorOrAnd: " + a
    print("")


    results = ss.getXor()
    for a in results:
      print "getXor: " + a
    print("")

    results = ss.getOr()
    for a in results:
      print "getOr: " + a
    print("")

    results = ss.getAnd()
    for a in results:
      print "getAnd: " + a
    print("")

    results =ss.getSixStarComments()
    results =ss.getExistingKnowledge()